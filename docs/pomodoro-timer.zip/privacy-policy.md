# Privacy Policy for CORTEX - Smart Pomodoro Timer

**Last Updated:** {{ CURRENT_DATE }}

Thank you for using CORTEX - Smart Pomodoro Timer ("the Extension"). This Privacy Policy explains what information the Extension collects, how it's used, and how it's protected. Your privacy is important to us, and we are committed to protecting it.

### 1. What Data We Collect

The Extension is designed to function with minimal data collection. The data we collect is stored locally on your computer and synced across your logged-in Chrome browsers using Chrome's built-in storage sync service. We do **not** have a server, and we do **not** have access to this data.

The data collected includes:

*   **Timer State:** The current state of your timer, including time left, whether it is running, the default duration, your currently set task (`currentTask`), the current mode (pomodoro/stopwatch), and reminder frequency.
*   **Stopwatch State:** The current state of the stopwatch, including the elapsed time and whether it is running.
*   **User Settings:** General settings for the extension, such as whether the timer is enabled and the duration you have set.
*   **Timer Position:** The position of the floating timer on your screen. This is saved on a per-website basis (e.g., `position_youtube.com`) to remember your preferred placement on different sites.
*   **Custom Sound Data:** If you upload a custom sound for reminders, the audio data is converted and stored locally within the extension's storage.

### 2. How We Use Your Data

The data collected is used exclusively to provide and improve the core functionality of the Extension. Specifically:

*   To save your timer's progress so it persists across browser sessions.
*   To synchronize your timer and settings across different devices where you are logged into Chrome.
*   To remember your preferred UI settings, such as the timer's position on different websites.
*   To enable features like task reminders and custom sounds.

We do **not** use your data for any other purpose, such as advertising, analytics, or tracking your browsing activity.

### 3. Data Storage and Security

All data is stored using the `chrome.storage.sync` and `chrome.storage.local` APIs provided by the Google Chrome browser. This means your data is stored securely on your local machine and, if you are logged into a Google account in Chrome, synced securely to your Google account. We, the developers of the Extension, do not have access to this data.

### 4. Third-Party Sharing

We do not share, sell, or transfer any of your data with any third parties.

### 5. Compliance with Chrome Web Store Policies

The use of information collected by this extension adheres to the Chrome Web Store User Data Policy, including the **Limited Use** requirements.

### 6. Changes to This Privacy Policy

We may update this Privacy Policy from time to time. We will notify you of any changes by posting the new Privacy Policy on this page and updating the "Last Updated" date.

### 7. Contact Us

If you have any questions about this Privacy Policy, please contact us at: [Your Email Address or Contact Page Link] 